from gradio.interface import Interface  # This makes it possible to import `Interface` as `gradio.Interface`.
